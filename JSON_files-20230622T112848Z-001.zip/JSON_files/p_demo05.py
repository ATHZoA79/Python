from urllib.request import urlopen   # 網路傳輸
import json

def scapper(url) :
    with urlopen(url) as file:
        data = json.loads(file.read())
        print(data)

while True :
    userInput = input("輸入路徑：")
    userInput = str(userInput)
    if userInput == 'q':
        break 
    scapper(str(userInput))